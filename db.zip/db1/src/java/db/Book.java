/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "book")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Book.findAll", query = "SELECT b FROM Book b"),
    @NamedQuery(name = "Book.findByBName", query = "SELECT b FROM Book b WHERE b.bName = :bName"),
    @NamedQuery(name = "Book.findByBId", query = "SELECT b FROM Book b WHERE b.bookPK.bId = :bId"),
    @NamedQuery(name = "Book.findByBEdition", query = "SELECT b FROM Book b WHERE b.bEdition = :bEdition"),
    @NamedQuery(name = "Book.findByBPrice", query = "SELECT b FROM Book b WHERE b.bPrice = :bPrice"),
    @NamedQuery(name = "Book.findByOId", query = "SELECT b FROM Book b WHERE b.oId = :oId"),
    @NamedQuery(name = "Book.findByBTId", query = "SELECT b FROM Book b WHERE b.bookPK.bTId = :bTId"),
    @NamedQuery(name = "Book.findByPId", query = "SELECT b FROM Book b WHERE b.pId = :pId")})
public class Book implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected BookPK bookPK;
    @Size(max = 40)
    @Column(name = "B_Name")
    private String bName;
    @Column(name = "B_Edition")
    private Long bEdition;
    @Column(name = "B_Price")
    private Long bPrice;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "O_Id")
    private String oId;
    @Size(max = 10)
    @Column(name = "P_Id")
    private String pId;
    @JoinColumn(name = "A_Id", referencedColumnName = "A_Id")
    @ManyToOne
    private Author aId;

    public Book() {
    }

    public Book(BookPK bookPK) {
        this.bookPK = bookPK;
    }

    public Book(BookPK bookPK, String oId) {
        this.bookPK = bookPK;
        this.oId = oId;
    }

    public Book(String bId, String bTId) {
        this.bookPK = new BookPK(bId, bTId);
    }

    public BookPK getBookPK() {
        return bookPK;
    }

    public void setBookPK(BookPK bookPK) {
        this.bookPK = bookPK;
    }

    public String getBName() {
        return bName;
    }

    public void setBName(String bName) {
        this.bName = bName;
    }

    public Long getBEdition() {
        return bEdition;
    }

    public void setBEdition(Long bEdition) {
        this.bEdition = bEdition;
    }

    public Long getBPrice() {
        return bPrice;
    }

    public void setBPrice(Long bPrice) {
        this.bPrice = bPrice;
    }

    public String getOId() {
        return oId;
    }

    public void setOId(String oId) {
        this.oId = oId;
    }

    public String getPId() {
        return pId;
    }

    public void setPId(String pId) {
        this.pId = pId;
    }

    public Author getAId() {
        return aId;
    }

    public void setAId(Author aId) {
        this.aId = aId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bookPK != null ? bookPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Book)) {
            return false;
        }
        Book other = (Book) object;
        if ((this.bookPK == null && other.bookPK != null) || (this.bookPK != null && !this.bookPK.equals(other.bookPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.Book[ bookPK=" + bookPK + " ]";
    }
    
}
