/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Administrator
 */
@Embeddable
public class BookPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "B_Id")
    private String bId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "BT_Id")
    private String bTId;

    public BookPK() {
    }

    public BookPK(String bId, String bTId) {
        this.bId = bId;
        this.bTId = bTId;
    }

    public String getBId() {
        return bId;
    }

    public void setBId(String bId) {
        this.bId = bId;
    }

    public String getBTId() {
        return bTId;
    }

    public void setBTId(String bTId) {
        this.bTId = bTId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bId != null ? bId.hashCode() : 0);
        hash += (bTId != null ? bTId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BookPK)) {
            return false;
        }
        BookPK other = (BookPK) object;
        if ((this.bId == null && other.bId != null) || (this.bId != null && !this.bId.equals(other.bId))) {
            return false;
        }
        if ((this.bTId == null && other.bTId != null) || (this.bTId != null && !this.bTId.equals(other.bTId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.BookPK[ bId=" + bId + ", bTId=" + bTId + " ]";
    }
    
}
