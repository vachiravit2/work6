/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "book_type")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "BookType.findAll", query = "SELECT b FROM BookType b"),
    @NamedQuery(name = "BookType.findByBTName", query = "SELECT b FROM BookType b WHERE b.bTName = :bTName"),
    @NamedQuery(name = "BookType.findByBTId", query = "SELECT b FROM BookType b WHERE b.bookTypePK.bTId = :bTId"),
    @NamedQuery(name = "BookType.findByBId", query = "SELECT b FROM BookType b WHERE b.bookTypePK.bId = :bId")})
public class BookType implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected BookTypePK bookTypePK;
    @Size(max = 40)
    @Column(name = "BT_Name")
    private String bTName;

    public BookType() {
    }

    public BookType(BookTypePK bookTypePK) {
        this.bookTypePK = bookTypePK;
    }

    public BookType(String bTId, String bId) {
        this.bookTypePK = new BookTypePK(bTId, bId);
    }

    public BookTypePK getBookTypePK() {
        return bookTypePK;
    }

    public void setBookTypePK(BookTypePK bookTypePK) {
        this.bookTypePK = bookTypePK;
    }

    public String getBTName() {
        return bTName;
    }

    public void setBTName(String bTName) {
        this.bTName = bTName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bookTypePK != null ? bookTypePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BookType)) {
            return false;
        }
        BookType other = (BookType) object;
        if ((this.bookTypePK == null && other.bookTypePK != null) || (this.bookTypePK != null && !this.bookTypePK.equals(other.bookTypePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.BookType[ bookTypePK=" + bookTypePK + " ]";
    }
    
}
